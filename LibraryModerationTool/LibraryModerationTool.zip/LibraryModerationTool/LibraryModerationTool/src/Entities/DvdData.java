package Entities;

public class DvdData {
    public int m;
    public int h;

    public DvdData(int h, int m) {
        this.h = h;
        this.m = m;
    }
}

